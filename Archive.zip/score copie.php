<?php 
	include('header.php');?>
<?php 
echo 'Bonjour ' . htmlspecialchars($_COOKIE["score"]) . '!';

?>
<?php
	include('footer.php'); 
?>