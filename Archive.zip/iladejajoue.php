<?php include('header.php'); ?>
<h4 class="rigatone">Veuillez réessayer demain</h4>
<a href="#">Cliquez ici pour recevoir un rappel</a>
<?php include('footer.php');?>