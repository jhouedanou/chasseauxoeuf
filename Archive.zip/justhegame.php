<?php 
	include('header.php');
	include('jeu.php');
	include('footer.php'); 
?>