<?php include('header.php'); ?>
<h4 class="rigatone">Réservé aux utilisateurs de l'application</h4>
<a href="#">Cliquez ici pour créer un compte</a>
<?php include('footer.php');?>